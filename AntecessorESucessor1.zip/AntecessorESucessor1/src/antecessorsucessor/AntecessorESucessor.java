package antecessorsucessor;

import java.util.Scanner;

public class AntecessorESucessor {
	public static void main(String[] args) {
		System.out.println("Digite um n�mero");
		Scanner N = new Scanner(System.in);
		int N1 = N.nextInt();
		System.out.println("Seu sucessor � " + (N1+1));
		System.out.println("E seu antecessor � " + (N1-1));
		
		
	}

}
