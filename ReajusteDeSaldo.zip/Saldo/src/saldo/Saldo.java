package saldo;

import java.util.Scanner;

public class Saldo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    double saldo;
    double rs;
    
    
    Scanner leitor = new Scanner(System.in);
    System.out.println("Informe seu saldo: ");
    saldo = leitor.nextDouble();
    
    double rds = saldo * 1.01; 
    
    System.out.println("Seu novo saldo � de " + rds);
    
     
	}

}
