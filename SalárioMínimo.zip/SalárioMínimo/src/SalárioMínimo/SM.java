package Sal�rioM�nimo;

import java.util.Scanner;

public class SM {

	public static void main(String[] args) {
		
		float SM = 788.00f;
		float S;
		float SM1;
		
		Scanner leitor = new Scanner(System.in);
		
		System.out.println("Digite o seu sal�rio");
		S = leitor.nextFloat();
		
		SM1 = S/SM;
		
		System.out.printf("Voc� ganha um total de %.0f sal�rio(s) m�nimo(s)", SM1);
		

	}

}
