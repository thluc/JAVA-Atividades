package CalculadorDeIdade1;

import java.util.Scanner;

public class CDE {
	public static void main(String[] args) {
		
		int dias = 30;
		int meses = 12;
		int anos = 365;
		int dia;
		int m�s;
		int ano;
		int idadeemdias;
		
		Scanner a = new Scanner(System.in);
		System.out.println("Digite a sua idade: ");
		ano = a.nextInt();
		
		System.out.println("Agora digite o m�s em que voc� nasceu: ");
		m�s = a.nextInt();
		
		System.out.println("Agora digite o dia: ");
		dia = a.nextInt();
		
		idadeemdias = ano * 365 + m�s * 30 + dias;
		
		System.out.println("Voc� tem " + idadeemdias + " dias de vida.");
	}

}
