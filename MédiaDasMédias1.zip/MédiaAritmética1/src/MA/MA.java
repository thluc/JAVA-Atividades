package MA;
public class MA {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       
       
       int media1 = (9+8+7)/3;
       int media2 = (5+6+4)/3;
       float media3 = (media1+media2)/2;
       System.out.println("A m�dia aritm�tica de 8,9 e 7 � " + media1);
       System.out.println("A m�dia aritm�tica de 5,6 e 4 � " + media2);
       System.out.println("A m�dia das m�dias � de " + media3);
	}

}

